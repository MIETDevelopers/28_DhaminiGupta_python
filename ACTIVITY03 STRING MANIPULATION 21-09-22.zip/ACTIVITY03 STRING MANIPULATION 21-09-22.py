# -*- coding: utf-8 -*-
"""
Created on Wed Sep 21 09:58:35 2022

@author: Muskan Raina
"""

#Date:21-09-22
#MUSKAN RAINA
#ACTIVITY 03


#             STRING MANIPULATION
#A) Count the number of alphabets in the given string
#Method1 : Using isalpha()+ len()
test_str = 'geeksforgeeks !!$ is best 4 all Geeks 10-0'
#printing original string
print("The original string is :" +str(test_str))
#isalpha() to computation of Alphabets
res = len([ele for ele in test_str if ele.isalpha()])
print("Count of Alphabets :" +str(res))

#Method2 : Using ascii_uppercase() + ascii_lowercase() +len()
import string
test_str = 'geeksforgeeks !!$ is best 4 all Geeks 10-0'
#printing original string
print("The original string is :" +str(test_str))
#ascii_lowercase and ascii_uppercase
res = len([ele for ele in test_str if ele in string.ascii_uppercase or ele in string.ascii_lowercase])
print("Count of Alphabets :" +str(res))

#B) To extract characters in the given,range from the given string
#Method 1: Using join()+list comprehension
test_list=["geeksforgeeks","is","best","for","geeks"]
#printing original string
print("The original string is :" +str(test_list))
strt,end=14,30
res = ''.join([sub for sub in test_list])[strt : end]
print("Range characters :"+str(res))

#C) Check if the string is alphanumeric or not
#Method 1: String isalnum()
string ="abc 123"
print(string, "isalphanumeric?",string.isalnum())
string ="abc_123"
print(string, "isalphanumeric?",string.isalnum())
string ="000"
print(string, "isalphanumeric?",string.isalnum())
string ="aaaa"
print(string, "isalphanumeric?",string.isalnum())

#Method 2:Isalnum() in if......else statement
password ="user123456"
if password.isalnum():
    print("Password is alphanumeric")
else:
    print("Password is not alphanumeric")    









