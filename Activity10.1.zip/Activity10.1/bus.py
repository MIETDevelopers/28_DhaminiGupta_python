class Vehicle:

    def __init__(self, name, max_speed, mileage):
        self.name = name   # instance of class
        self.max_speed = max_speed
        self.mileage = mileage

    def speed(self): #method of Vehicle class
        return f'The vehicle has {self.max_speed} Maximum Speed'

class Bus(Vehicle): # inheriting the Vehicle class
   
    def __init__(self,name, max_speed, mileage,color):
        self.name = name
        self.max_speed = max_speed
        self.mileage = mileage
        self.color = color

bu_s= Bus("Volvo",250, 15,"black") # creating Object

print("Vehicle Name is ",bu_s.name, " has maximum Speed of",bu_s.max_speed, " with Mileage of", bu_s.mileage," with",bu_s.color,"color")
print("Vehicle has maximum speed of",bu_s.max_speed) # Accessing Object
