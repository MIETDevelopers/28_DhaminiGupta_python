# all +ve number is range 
# a=-2;b=10
a=int(input("enter the first number:"))
b=int(input("enter the second number:"))
for i in range(a,b+1):
    if i<0:
        pass
    else:
        print(i,end=" ")



