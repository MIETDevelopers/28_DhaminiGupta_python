li=[23,56,345,34]

print("The given list is:" + str(li))

sum_dight=[]

for i in li:
    sum=0
    for dig in str(i):
        sum+=int(dig)
    sum_dight.append(sum)

print("Sum of Digit is:" + str(sum_dight))