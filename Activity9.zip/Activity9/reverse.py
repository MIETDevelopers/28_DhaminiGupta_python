
string = "this is string"

ds = string.split()[::-1]
# print(ds)
sm = []
for i in ds:
    sm.append(i)
# printing reverse words
print(" ".join(sm))