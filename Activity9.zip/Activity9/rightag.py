import math
a=float(input("enter the first number:"))
b=float(input("enter the second number:"))
c=float(input("enter the third number:"))
#  Applying Pythagorus Theorem which states that sum of squares of other sides is equal to square of largest side
if a**2+b**2==c**2:
    print("Triangle is Right Angled")
elif c**2 + a**2 == b**2:
    print("Triangle is Right Angled")
elif b**2 + c**2 == a**2:
    print("Triangle is Right Angled")
else:
    print("Triangle is Not Right Angled") 
'''
we can use both methods as given on the top or we can firsty find the largest_triangle_side and then apply Pythagorus Theorem
if (a >= b) and (a >= c):
	largest_triangle_side = a
elif (b >= c) and (b >= a):
	largest_triangle_side = b
else:
	largest_triangle_side = c

if (largest_triangle_side == a):
    if (b**2 + c**2 == a**2):
        print("Triangle is Right Angled")
    else:
        print("Triangle is Not Right Angled")

# If b is largest side of triangle
if(largest_triangle_side == b):
    if(c**2 + a**2 == b**2):
        print("Triangle is Right Angled")
    else:
        print("Triangle is Not Right Angled")

# If c is largest side of triangle
if(largest_triangle_side == c):
    if(a**2 + b**2 == c**2):
        print("Triangle is Right Angled")
    else:
        print("Triangle is Not Right Angled")  
'''

'''Area Of Triangle using Heron's Formula
Heron’s formula for calculating the semi-perimeter which is s=(a+b+c)/2.
Area = math.sqrt(s*(s-a)*(s-b)*(s-c)) to calculate the area of the triangle.'''
s=(a+b+c)/2
area=math.sqrt(s*(s-a)*(s-b)*(s-c))

print("The area of triangle is",'%.2f'%area)













