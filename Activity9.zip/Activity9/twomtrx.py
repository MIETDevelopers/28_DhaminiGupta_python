# using numpy
import numpy as np

A = [[4, 7, 2],
    [4, 3, 6],
    [7, 8, 4]]
 
B = [[5, 8, 1],
    [6, 7, 3],
    [4, 5,1]]

result= [[0,0,0],
        [0,0,0],
        [0,0,0]]
 
result = np.dot(A,B)
 
for r in result:
    print(r)