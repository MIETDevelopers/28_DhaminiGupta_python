#Python program to create a Vehicle class  with max_speed and mileage instance attributes.  


class Vehicle:  # creating class
    def __init__(self,max_speed ,mileage ):
        self.max_speed = max_speed  # creating  first instance of the class
        self.mileage = mileage    # creating 2nd instance of the class

model = Vehicle(280,25) #creating opbejct of the class
print(model.max_speed,model.mileage)