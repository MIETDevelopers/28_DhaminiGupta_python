# Vehicle class without any variables and methods

class Vehicle:
    pass