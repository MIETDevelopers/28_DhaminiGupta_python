# -*- coding: utf-8 -*-
"""
Created on Mon Sep 12 10:21:00 2022

@author: Muskan Raina
"""
#Muskan Raina
#Date:12-09-22
#1.Program to find even no.from a list
a=[2,4,6,8,9,3,5]
for n in a:
   if n%2 == 0:
     print(n)
     
#2.Interchange First and Last Element Of a list     
a=[2,3,4,6,7,9,22,10,44,21,8]
a[0],a[-1]=a[-1],a[0]
print(a)
     
#3.Program to merge two list   
a=[4,5,6]
b=[7,3,2] 
a.extend(b)
print(a)