'''Python Program to convert temprature in celsius to fahrenheit'''

celsius=37.5
fahrenheit=(celsius*1.8)+32
print('%0.1f degree Celsius is equel to %0.1f degree Fahrenheit'%(celsius,fahrenheit))